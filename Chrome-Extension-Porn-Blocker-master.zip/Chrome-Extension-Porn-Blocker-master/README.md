# Chrome Extension : Porn Blocker
This chrome extension block the pornography sites, saving your child from THE INTERNET.

Source Code available here.   
Download and install the extension from web store: https://chrome.google.com/webstore/detail/porn-blocker/odfaaonbinobeomfaaepmjjhodelkkke  

For more extensions visit: https://sites.google.com/site/wowcex1234/
